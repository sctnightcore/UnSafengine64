// External Function Reader
// 2020. 5. 11.
// seogu.choi@gmail.com
#include "PinHelper.h"

bool read_exports(ADDRINT saddr, vector<ADDRINT>& v_fn_addr, vector<string>& v_fn_name);
