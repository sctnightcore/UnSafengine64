#pragma once

const char* get_crt_dll_name(const char* ucrt_fname);
const char* get_ntdll_to_kernel32_name(const char* ntdll_name);
